BARBRO — first website prototype

FILES
- index.html: the complete first version of the BARBRO website.

PUBLISH WITH GITHUB (PHONE OR TABLET)
1. Extract this ZIP on your device.
2. Open Chrome and go to github.com. Sign in and open your BARBRO repository.
3. If the mobile layout does not show upload controls, open Chrome's ⋮ menu and turn on Desktop site.
4. In the repository, choose Add file → Upload files.
5. Upload index.html (not the ZIP file itself).
6. Scroll down, enter a commit message such as "Add BARBRO website", then choose Commit changes.

TURN ON GITHUB PAGES
1. In the repository, open Settings.
2. Open Pages.
3. Under Build and deployment, choose Deploy from a branch.
4. Select branch main and folder /(root), then Save.
5. Wait for GitHub Pages to publish. The site address will be shown in Settings → Pages.

WHAT THIS VERSION DOES
- Requests browser location only after the visitor taps the location button.
- Searches OpenStreetMap for nearby hairdresser/barber listings within 10 km.
- Shows distance and lets visitors add a 1–5 star rating.

IMPORTANT LIMITATIONS
- This is a front-end prototype. Ratings are stored only in the current browser/device and are not shared with other users.
- A proper shared review system, accounts, bookings, and business-owner profiles need a secure backend/database.
- Location search needs internet access and browser location permission. The OpenStreetMap data may be incomplete.
